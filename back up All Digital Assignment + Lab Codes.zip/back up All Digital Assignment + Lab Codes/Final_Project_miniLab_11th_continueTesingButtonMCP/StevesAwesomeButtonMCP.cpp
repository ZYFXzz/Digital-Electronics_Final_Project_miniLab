#include "Arduino.h"
#include <Adafruit_MCP23X17.h>
#include "StevesAwesomeButtonMCP.h"



StevesAwesomeButtonMCP::StevesAwesomeButtonMCP(int _buttonPin, int _buttonNum, int _buttonType)
{
  buttonPin = _buttonPin;
  buttonNum = _buttonNum;
  buttonState = 0;
  lastButtonState = 0;
  buttonType = _buttonType;

  if (buttonType == INPUT) {
    onState = HIGH;
    offState = LOW;
  } else {
    onState = LOW;
    offState = HIGH;
  }
  mcp = new Adafruit_MCP23X17();
  mcp->begin_I2C(); // initialize the MCP object
  mcp->pinMode(buttonPin, buttonType);

  // // initialize the MCP23X17
  // if (!mcp.begin_I2C()) {
  //   Serial.println("Failed to initialize MCP23X17!");
  //   while (1);
  // }

  // mcp.pinMode(buttonPin, buttonType);
}


void StevesAwesomeButtonMCP::processMCP()
{
  lastButtonState = buttonState;
  buttonState = mcp->digitalRead(buttonPin);

  if (lastButtonState == offState && buttonState == onState) {
    if (pressCallbackMCP != NULL) pressCallbackMCP(buttonNum);
    delay(5);
  }
  else if (lastButtonState == onState && buttonState == onState) {
    if (holdCallbackMCP != NULL) holdCallbackMCP(buttonNum);
    delay(5);
  }
  else if (lastButtonState == onState && buttonState == offState) {
    if (releaseCallbackMCP != NULL) releaseCallbackMCP(buttonNum);
    delay(5);
  }
}

void StevesAwesomeButtonMCP::pressHandlerMCP(void (*f)(int))    //button down
{
  pressCallbackMCP = *f;
}

void StevesAwesomeButtonMCP::holdHandlerMCP(void (*f)(int))  //button hold
{
  holdCallbackMCP = *f;
}

void StevesAwesomeButtonMCP::releaseHandlerMCP(void (*f)(int))  //button release
{
  releaseCallbackMCP = *f;
}
