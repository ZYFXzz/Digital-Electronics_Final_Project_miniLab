#ifndef audio_system
#define audio_system

#include <Audio.h>
#include <Wire.h>
#include <SPI.h>
#include <SD.h>
#include <SerialFlash.h>

// GUItool: begin automatically generated code
AudioSynthWaveformModulated waveform4;      //xy=135,309.9999952316284
AudioSynthWaveformModulated waveform3;      //xy=137,260.9999952316284
AudioSynthWaveformModulated waveform1;      //xy=138,146.99999523162842
AudioSynthWaveformModulated waveform2;      //xy=138,200.99999523162842
AudioSynthKarplusStrong  string1;        //xy=294,377.9999952316284
AudioSynthSimpleDrum     drum3;          //xy=293,659.9999952316284
AudioSynthSimpleDrum     drum1;          //xy=294,578.9999952316284
AudioPlayMemory          playMem3;       //xy=293.33332443237305,834.9999570846558
AudioEffectEnvelope      envelope4;      //xy=296,313.9999952316284
AudioEffectEnvelope      envelope1;      //xy=297,149.99999523162842
AudioEffectEnvelope      envelope2;      //xy=297,202.99999523162842
AudioPlayMemory          playMem1;       //xy=295.00000762939453,749.9999961853027
AudioSynthKarplusStrong  string4;        //xy=296,507.9999952316284
AudioEffectEnvelope      envelope3;      //xy=297,260.9999952316284
AudioPlayMemory          playMem2;       //xy=295.0000114440918,791.6666831970215
AudioSynthSimpleDrum     drum2;          //xy=296,619.9999952316284
AudioPlayMemory          playMem4;       //xy=294.9999885559082,874.9999589920044
AudioSynthKarplusStrong  string2;        //xy=297,419.9999952316284
AudioSynthSimpleDrum     drum4;          //xy=296,699.9999952316284
AudioPlayMemory          playMem7; //xy=295.4166450500488,1012.0833158493042
AudioSynthKarplusStrong  string3;        //xy=298,459.9999952316284
AudioPlayMemory          playMem5; //xy=297.0833282470703,927.0833549499512
AudioPlayMemory          playMem6; //xy=297.0833320617676,968.7500419616699
AudioPlayMemory          playMem8; //xy=297.083309173584,1052.0833177566528
AudioMixer4              mixer2;         //xy=488,434.9999952316284
AudioMixer4              mixer1;         //xy=490,204.99999523162842
AudioMixer4              mixer4;         //xy=491,614.9999952316284
AudioMixer4              mixer5;         //xy=491.6666793823242,803.3333282470703
AudioMixer4              mixer6; //xy=493.75,980.4166870117188
AudioSynthWaveform       lfo1;           //xy=647,366
AudioMixer4              mixer7;         //xy=645.0000381469727,884.9999961853027
AudioMixer4              mixer3;         //xy=650,305.9999952316284
AudioEffectMultiply      multiply1;      //xy=809,343
AudioMixer4              multiplyMixer;  //xy=986,303.9999952316284
AudioAmplifier           amp2;           //xy=1167,334.9999952316284
AudioAmplifier           amp1;           //xy=1168,277.9999952316284
AudioAnalyzePeak         peak1;          //xy=1170,426.9999952316284
AudioOutputI2S           i2s1;           //xy=1322,299.9999952316284
AudioConnection          patchCord1(waveform4, envelope4);
AudioConnection          patchCord2(waveform3, envelope3);
AudioConnection          patchCord3(waveform1, envelope1);
AudioConnection          patchCord4(waveform2, envelope2);
AudioConnection          patchCord5(string1, 0, mixer2, 0);
AudioConnection          patchCord6(drum3, 0, mixer4, 2);
AudioConnection          patchCord7(drum1, 0, mixer4, 0);
AudioConnection          patchCord8(playMem3, 0, mixer5, 2);
AudioConnection          patchCord9(envelope4, 0, mixer1, 3);
AudioConnection          patchCord10(envelope1, 0, mixer1, 0);
AudioConnection          patchCord11(envelope2, 0, mixer1, 1);
AudioConnection          patchCord12(playMem1, 0, mixer5, 0);
AudioConnection          patchCord13(string4, 0, mixer2, 3);
AudioConnection          patchCord14(envelope3, 0, mixer1, 2);
AudioConnection          patchCord15(playMem2, 0, mixer5, 1);
AudioConnection          patchCord16(drum2, 0, mixer4, 1);
AudioConnection          patchCord17(playMem4, 0, mixer5, 3);
AudioConnection          patchCord18(string2, 0, mixer2, 1);
AudioConnection          patchCord19(drum4, 0, mixer4, 3);
AudioConnection          patchCord20(playMem7, 0, mixer6, 2);
AudioConnection          patchCord21(string3, 0, mixer2, 2);
AudioConnection          patchCord22(playMem5, 0, mixer6, 0);
AudioConnection          patchCord23(playMem6, 0, mixer6, 1);
AudioConnection          patchCord24(playMem8, 0, mixer6, 3);
AudioConnection          patchCord25(mixer2, 0, mixer3, 1);
AudioConnection          patchCord26(mixer1, 0, mixer3, 0);
AudioConnection          patchCord27(mixer4, 0, mixer3, 2);
AudioConnection          patchCord28(mixer5, 0, mixer7, 0);
AudioConnection          patchCord29(mixer6, 0, mixer7, 1);
AudioConnection          patchCord30(lfo1, 0, multiply1, 1);
AudioConnection          patchCord31(mixer7, 0, mixer3, 3);
AudioConnection          patchCord32(mixer3, 0, multiply1, 0);
AudioConnection          patchCord33(mixer3, 0, multiplyMixer, 0);
AudioConnection          patchCord34(multiply1, 0, multiplyMixer, 1);
AudioConnection          patchCord35(multiplyMixer, amp1);
AudioConnection          patchCord36(multiplyMixer, amp2);
AudioConnection          patchCord37(multiplyMixer, peak1);
AudioConnection          patchCord38(amp2, 0, i2s1, 1);
AudioConnection          patchCord39(amp1, 0, i2s1, 0);
AudioControlSGTL5000     sgtl5000_1;     //xy=717,127.99999237060547
// GUItool: end automatically generated code

#endif