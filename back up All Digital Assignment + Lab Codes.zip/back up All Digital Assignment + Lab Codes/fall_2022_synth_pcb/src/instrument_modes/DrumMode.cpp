#include "DrumMode.h"
#include <Audio.h>
#include "Arduino.h"
#include <Adafruit_NeoPixel.h>
#include "../ui/StevesAwesomeOledController.h"

DrumMode::DrumMode(AudioSynthSimpleDrum *_drums, int _length, Adafruit_NeoPixel *_neopixel, StevesAwesomeOledController* _oled)
{
  drums = _drums;
  length = _length;
  neopixel = _neopixel;
  oled = _oled;

  for (int i = 0; i < 4; i++)
  {
    (drums + i)->length(drumLength);
    (drums + i)->secondMix(secondMix);
    (drums + i)->pitchMod(pitchMod);
  }
}

void DrumMode::displayOled()
{
}

void DrumMode::displayNeoPixels()
{
  // adopted from strandtest from Adafruit_NeoPixel examples
  int speed = 10;
  if (millis() > lastFrame + speed)
  {
    lastFrame = millis();
    for (int i = 0; i < neopixel->numPixels(); i++)
    { // For each pixel in strip...
      // the *2 is significant... higher numbers mean slower washes, fractions faster ones
      int pixelHue = firstPixelHue + (i * 65536L / (neopixel->numPixels() * 4));
      neopixel->setPixelColor(i, neopixel->gamma32(neopixel->ColorHSV(pixelHue)));
    }
    //    strip.setBrightness(5 + peak * 100);
    neopixel->setBrightness(100);
    neopixel->show(); // Update strip with new contents
    firstPixelHue += 256;
    if (firstPixelHue >= 5 * 65536)
      firstPixelHue = 0;
  }
}

void DrumMode::onNoteButtonPress(int _num)
{
  int f = freq[_num + octave];

  for (int i = 0; i < totalOscs; i++)
  {
    if (currentFreq[i] == -1)
    {
      (drums + i)->frequency(f);
      (drums + i)->noteOn();
      currentFreq[i] = f;
      notesPlaying++;
      break;
    }
  }
}

void DrumMode::onNoteButtonHold(int _num)
{
}

void DrumMode::onNoteButtonRelease(int _num)
{
  int f = freq[_num + octave];
  for (int i = 0; i < totalOscs; i++)
  {
    if (currentFreq[i] == f)
    {
      currentFreq[i] = -1;
      notesPlaying--;
      break;
    }
  }
}

void DrumMode::option1ButtonPress()
{
  changeOctave();
}

void DrumMode::option2ButtonPress()
{
}

void DrumMode::changeOctave()
{
  // increment the octave
  octaveNum++;
  if (octaveNum >= totalOctaves)
    octaveNum = 0;

  // switch the octave obvs
  octave = octaveNum * 12;

  // turn off all notes and free them for new notes
  for (int i = 0; i < totalOscs; i++)
  {
    currentFreq[i] = -1;
  }
}

// void DrumMode::updatePotVals(int *_potVals)
// {
//   for (int i = 0; i < 4; i++)
//   {
//     (drums + i)->length(map(*(_potVals), 0, 1023, 100, 2000));
//     (drums + i)->secondMix(map(*(_potVals + 1), 0, 1023, 0, 100) / 100.0);
//     (drums + i)->pitchMod(map(*(_potVals + 2), 0, 1023, 0, 100) / 100.0);
//   }
// }

void DrumMode::updatePotVal(int _potNum, int _val)
{
  if(_potNum == 0) drumLength = map(_val, 0, 1023, 100, 2000);
  else if(_potNum == 1) secondMix = map(_val, 0, 1023, 0, 100) / 100.0;
  else if(_potNum == 2) pitchMod = map(_val, 0, 1023, 0, 100) / 100.0;

  updateParams();
}

void DrumMode::updateParams()
{
  for (int i = 0; i < 4; i++)
  {
    (drums + i)->length(drumLength);
    (drums + i)->secondMix(secondMix);
    (drums + i)->pitchMod(pitchMod);
  }
}


void DrumMode::update()
{
  displayNeoPixels();
}

void DrumMode::open()
{
  oled->clear();
}

void DrumMode::close()
{

}