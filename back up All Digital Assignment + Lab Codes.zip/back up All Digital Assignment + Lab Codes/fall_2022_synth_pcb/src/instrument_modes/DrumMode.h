#ifndef DrumMode_h
#define DrumMode_h

#include "InstrumentMode.h"
#include <Audio.h>
#include <Adafruit_NeoPixel.h>
#include "../ui/StevesAwesomeOledController.h"

class DrumMode : public InstrumentMode
{
public:
    DrumMode(AudioSynthSimpleDrum *_drums, int _length, Adafruit_NeoPixel *_neopixel, StevesAwesomeOledController* _oled);
    void displayOled();
    void displayNeoPixels();
    void onNoteButtonPress(int _num);
    void onNoteButtonHold(int _num);
    void onNoteButtonRelease(int _num);
    void option1ButtonPress();
    void option2ButtonPress();
    // void updatePotVals(int *_potVals);
    void updatePotVal(int _potNum, int _val);
    void update();
    void open();
    void close();

private:
    AudioSynthSimpleDrum *drums;
    int length;
    Adafruit_NeoPixel *neopixel;
    StevesAwesomeOledController* oled;

    void changeOctave();
    void updateParams();

    int waveforms[4] = {WAVEFORM_SAWTOOTH, WAVEFORM_SQUARE, WAVEFORM_TRIANGLE, WAVEFORM_SAMPLE_HOLD};
    int octave = 0;
    int octaveNum = 0;
    int totalOctaves = 3;
    int totalOscs = 4;
    int currentOsc = 0;
    int currentFreq[4] = {-1, -1, -1, -1};
    float oscVolume = 0.3;
    int notesPlaying = 0;
    int freq[49] = {131, 139, 147, 156, 165, 175, 185, 196, 208, 220, 233, 247, 262, 277, 294, 311, 330, 349, 370, 392, 415, 440, 466, 494, 523, 554, 587, 622, 659, 698, 740, 784, 831, 880, 932, 988, 1047, 1109, 1175, 1245, 1319, 1397, 1480, 1568, 1661, 1760, 1865, 1976, 2093};
    int drumLength = 1000;
    float secondMix = 0.5;
    float pitchMod = 0.6;

    // neopixel
    unsigned long lastFrame = 0;
    unsigned long firstPixelHue = 0;
};

#endif