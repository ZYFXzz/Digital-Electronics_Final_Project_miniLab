#ifndef InstrumentMode_h
#define InstrumentMode_h

class InstrumentMode
{
    public:
        virtual void displayOled() = 0;
        virtual void displayNeoPixels() = 0;
        virtual void onNoteButtonPress(int _num) = 0;
        virtual void onNoteButtonHold(int _num) = 0;
        virtual void onNoteButtonRelease(int _num) = 0;
        virtual void option1ButtonPress() = 0;
        virtual void option2ButtonPress() = 0;
        virtual void update() = 0;
        // virtual void updatePotVals(int* _potVals);
        virtual void updatePotVal(int _potNum, int _val);
        virtual void open();
        virtual void close();
};

#endif