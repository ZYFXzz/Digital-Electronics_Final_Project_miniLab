#include "SequencerMode.h"
#include "../ui/StevesAwesomeOledController.h"
#include "Arduino.h"
#include <Audio.h>

SequencerMode::SequencerMode(AudioPlayMemory *_playMems, int _length,
                             Adafruit_NeoPixel *_neopixel,
                             StevesAwesomeOledController *_oled) {
  playMems = _playMems;
  length = _length;
  neopixel = _neopixel;
  oled = _oled;
}

void SequencerMode::displayOled() {}

void SequencerMode::displayNeoPixels() {
  for (int i = 0; i < numSteps; i++) {
    if (i == thisChannelCurrentStep[currentChannel])
      neopixel->setPixelColor(i, channelColors[currentChannel][0],
                              channelColors[currentChannel][1],
                              channelColors[currentChannel][2]);
    else if (stepOn[currentChannel][i] == HIGH)
      neopixel->setPixelColor(i, channelColors[currentChannel][0] * 0.5,
                              channelColors[currentChannel][1] * 0.5,
                              channelColors[currentChannel][2] * 0.5);
    else
      neopixel->setPixelColor(i, 0, 0, 0);
  }
  neopixel->setBrightness(50);
  neopixel->show();
}

void SequencerMode::onNoteButtonPress(int _num) 
{
  if (_num == 1) editLengthMode = true; // { // if its c#

  if (editLengthMode == false) {
    for (int i = 0; i < numSteps; i++) {
      if (_num == sequencerButtonNums[i])
        stepOn[currentChannel][i] = !stepOn[currentChannel][i];
    }
  } else if (editLengthMode == true) {
    for (int i = 0; i < numSteps; i++) {
      if (_num == sequencerButtonNums[i])
        thisChannelSteps[currentChannel] = i + 1;
    }
  }
}

void SequencerMode::onNoteButtonHold(int _num) {}

void SequencerMode::onNoteButtonRelease(int _num) {
  if (_num == 1) { // if its c#
    editLengthMode = false;
  }
}

void SequencerMode::option1ButtonPress() {
  currentChannel++;
  if (currentChannel >= numChannels) currentChannel = 0;
}

void SequencerMode::option2ButtonPress() {
  currentChannel--;
  if (currentChannel < 0) currentChannel = numChannels - 1;
}

// void SequencerMode::updatePotVals(int *_potVals)
// {
//   tempo = map(*(_potVals), 0, 1023, 1000, 50);
// }

void SequencerMode::updatePotVal(int _potNum, int _val) {
  if (_potNum == 0) tempo = map(_val, 0, 1023, 1000, 50);
}

void SequencerMode::update() {
  sequence();
  displayNeoPixels();
}

void SequencerMode::open() {
  oled->clear();
  neopixel->clear();
  neopixel->show();
  lastStepTime = millis();
  for (int i = 0; i < numChannels; i++) {
    thisChannelCurrentStep[i] = -1;
  }
}

void SequencerMode::close() {}

void SequencerMode::sequence() {
  if (millis() >= lastStepTime + tempo) {
    lastStepTime = lastStepTime + tempo;

    for (int i = 0; i < numChannels; i++) {
      thisChannelCurrentStep[i]++;
      if (thisChannelCurrentStep[i] >= thisChannelSteps[i])
        thisChannelCurrentStep[i] = 0;
    }

    for (int i = 0; i < numChannels; i++) {
      if (stepOn[i][thisChannelCurrentStep[i]] == HIGH)
        (playMems + i)->play(samples[i]);
    }
  }
}