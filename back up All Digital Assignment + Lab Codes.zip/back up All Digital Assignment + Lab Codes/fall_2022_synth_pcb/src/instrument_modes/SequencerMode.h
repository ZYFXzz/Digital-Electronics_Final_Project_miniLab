#ifndef SequencerMode_h
#define SequencerMode_h

#include "InstrumentMode.h"
#include <Audio.h>
#include <Adafruit_NeoPixel.h>
#include "../ui/StevesAwesomeOledController.h"

// sequencer mode
#include "samples/AudioSampleSnare808.h"
#include "samples/AudioSampleClosedhihat808.h"
#include "samples/AudioSampleKick808.h"
#include "samples/AudioSampleClap808.h"
#include "samples/AudioSampleOpenhihat808.h"
#include "samples/AudioSampleCowbell808.h"
#include "samples/AudioSampleRimshot808.h"
#include "samples/AudioSampleClave808.h"

class SequencerMode : public InstrumentMode
{
public:
    SequencerMode(AudioPlayMemory *_playMems, int _length, Adafruit_NeoPixel *_neopixel, StevesAwesomeOledController* _oled);
    void displayOled();
    void displayNeoPixels();
    void onNoteButtonPress(int _num);
    void onNoteButtonHold(int _num);
    void onNoteButtonRelease(int _num);
    void option1ButtonPress();
    void option2ButtonPress();
    // void updatePotVals(int *_potVals);
    void updatePotVal(int _potNum, int _val);
    void update();
    void open();
    void close();

private:
    AudioPlayMemory *playMems;
    const unsigned int *samples[8] = {AudioSampleKick808, AudioSampleSnare808, AudioSampleClosedhihat808, AudioSampleOpenhihat808, AudioSampleClap808, AudioSampleCowbell808, AudioSampleRimshot808, AudioSampleClave808};
    int length;
    Adafruit_NeoPixel *neopixel;
    StevesAwesomeOledController* oled;
    int sequencerButtonNums[8] = {0, 2, 4, 5, 7, 9, 11, 12};
    const int numSteps = 8;
    int currentStep = 0;
    uint32_t tempo = 250;
    uint32_t lastStepTime = 0;
    int currentChannel = 0;
    const int numChannels = 8;
    int stepOn[8][8] = {
        {LOW, LOW, LOW, LOW, LOW, LOW, LOW, LOW},
        {LOW, LOW, LOW, LOW, LOW, LOW, LOW, LOW},
        {LOW, LOW, LOW, LOW, LOW, LOW, LOW, LOW},
        {LOW, LOW, LOW, LOW, LOW, LOW, LOW, LOW},
        {LOW, LOW, LOW, LOW, LOW, LOW, LOW, LOW},
        {LOW, LOW, LOW, LOW, LOW, LOW, LOW, LOW},
        {LOW, LOW, LOW, LOW, LOW, LOW, LOW, LOW},
        {LOW, LOW, LOW, LOW, LOW, LOW, LOW, LOW}};
    int channelColors[8][3] = {
        {0, 128, 128},
        {128, 128, 0},
        {128, 0, 128},
        {128, 128, 128},
        {0, 64, 192},
        {64, 192, 0},
        {192, 0, 64},
        {64, 128, 192}};
    int thisChannelSteps[8] = {8, 8, 8, 8, 8, 8, 8, 8};
    int thisChannelCurrentStep[8] = {0, 0, 0, 0, 0, 0, 0, 0};
    int editLengthMode = false;

    void sequence();

    // neopixel
    unsigned long lastFrame = 0;
    unsigned long firstPixelHue = 0;
};

#endif