#include "StringMode.h"
#include <Audio.h>
#include "Arduino.h"
#include <Adafruit_NeoPixel.h>
#include "../ui/StevesAwesomeOledController.h"

StringMode::StringMode(AudioSynthKarplusStrong *_strings, int _length, Adafruit_NeoPixel *_neopixel, StevesAwesomeOledController* _oled)
{
  strings = _strings;
  length = _length;
  neopixel = _neopixel;
  oled = _oled;
}

void StringMode::displayOled()
{
}

void StringMode::displayNeoPixels()
{
  // adopted from strandtest from Adafruit_NeoPixel examples
  int speed = 10;
  if (millis() > lastFrame + speed)
  {

    lastFrame = millis();
    for (int i = 0; i < neopixel->numPixels(); i++)
    { // For each pixel in strip...
      // the *2 is significant... higher numbers mean slower washes, fractions faster ones
      int pixelHue = firstPixelHue + (i * 65536L / (neopixel->numPixels() * 4));
      neopixel->setPixelColor(i, neopixel->gamma32(neopixel->ColorHSV(pixelHue)));
    }
    //    strip.setBrightness(5 + peak * 100);
    neopixel->setBrightness(100);
    neopixel->show(); // Update strip with new contents
    firstPixelHue += 256;
    if (firstPixelHue >= 5 * 65536)
      firstPixelHue = 0;
  }
}

void StringMode::onNoteButtonPress(int _num)
{

  int f = freq[_num + octave];

  for (int i = 0; i < length; i++)
  {
    if (currentFreq[i] == -1)
    {
      (strings + i)->noteOn(f, stringNoteOnVelocity);
      currentFreq[i] = f;
      notesPlaying++;
      break;
    }
  }
}

void StringMode::onNoteButtonHold(int _num)
{
}

void StringMode::onNoteButtonRelease(int _num)
{

  int f = freq[_num + octave];

  for (int i = 0; i < totalOscs; i++)
  {
    if (currentFreq[i] == f)
    {
      (strings + i)->noteOff(stringNoteOffVelocity);
      currentFreq[i] = -1;
      notesPlaying--;
    }
  }
}

void StringMode::option1ButtonPress()
{
  changeOctave();
}

void StringMode::option2ButtonPress()
{
}

void StringMode::changeOctave()
{

  // increment the octave
  octaveNum++;
  if (octaveNum >= totalOctaves)
    octaveNum = 0;

  // switch the octave obvs
  octave = octaveNum * 12;
}

// void StringMode::updatePotVals(int *_potVals)
// {
//   stringNoteOnVelocity = map(*(_potVals), 0, 1023, 10, 100) / 100.0;
//   stringNoteOffVelocity = map(*(_potVals + 1), 0, 1023, 0, 100) / 100.0;
// }

void StringMode::updatePotVal(int _potNum, int _val)
{
  if(_potNum == 0) stringNoteOnVelocity = map(_val, 0, 1023, 10, 100) / 100.0;
  else if(_potNum == 1) stringNoteOffVelocity = map(_val, 0, 1023, 10, 100) / 100.0;
}

void StringMode::update()
{
  displayNeoPixels();
}

void StringMode::open()
{
  oled->clear();
}

void StringMode::close()
{

}