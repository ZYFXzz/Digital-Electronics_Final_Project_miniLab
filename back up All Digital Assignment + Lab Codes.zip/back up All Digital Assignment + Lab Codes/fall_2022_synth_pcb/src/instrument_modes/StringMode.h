#ifndef StringMode_h
#define StringMode_h

#include "InstrumentMode.h"
#include <Audio.h>
#include <Adafruit_NeoPixel.h>
#include "../ui/StevesAwesomeOledController.h"

class StringMode : public InstrumentMode
{
public:
    StringMode(AudioSynthKarplusStrong *_strings, int _length, Adafruit_NeoPixel *_neopixel, StevesAwesomeOledController* _oled);
    void displayOled();
    void displayNeoPixels();
    void onNoteButtonPress(int _num);
    void onNoteButtonHold(int _num);
    void onNoteButtonRelease(int _num);
    void option1ButtonPress();
    void option2ButtonPress();
    // void updatePotVals(int *_potVals);
    void updatePotVal(int _potNum, int _val);
    void update();
    void open();
    void close();

private:
    AudioSynthKarplusStrong *strings;
    int length;
    Adafruit_NeoPixel *neopixel;
    StevesAwesomeOledController* oled;
    float stringNoteOnVelocity = 1.0;
    float stringNoteOffVelocity = 0;
    void changeOctave();
    int octave = 0;
    int octaveNum = 0;
    int totalOctaves = 3;
    int totalOscs = 4;
    int currentOsc = 0;
    int currentFreq[4] = {-1, -1, -1, -1};
    float oscVolume = 0.3;
    int notesPlaying = 0;
    int freq[49] = {131, 139, 147, 156, 165, 175, 185, 196, 208, 220, 233, 247, 262, 277, 294, 311, 330, 349, 370, 392, 415, 440, 466, 494, 523, 554, 587, 622, 659, 698, 740, 784, 831, 880, 932, 988, 1047, 1109, 1175, 1245, 1319, 1397, 1480, 1568, 1661, 1760, 1865, 1976, 2093};

    // neopixel
    unsigned long lastFrame = 0;
    unsigned long firstPixelHue = 0;
};

#endif