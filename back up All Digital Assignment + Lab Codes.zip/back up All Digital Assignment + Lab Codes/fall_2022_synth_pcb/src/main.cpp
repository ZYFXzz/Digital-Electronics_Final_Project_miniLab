#include "audio_system.h"
#include "function_declarations.h"
#include "instrument_modes/DrumMode.h"
#include "instrument_modes/InstrumentMode.h"
#include "instrument_modes/SequencerMode.h"
#include "instrument_modes/StringMode.h"
#include "instrument_modes/SynthMode.h"
#include "ui/StevesAwesomeButton.h"
#include "ui/StevesAwesomeOledController.h"
#include "ui/StevesAwesomePotentiometer.h"
#include "ui/StevesAwesomeRotaryEncoder.h"
#include <Adafruit_GFX.h>
#include <Adafruit_NeoPixel.h>
#include <Adafruit_SSD1306.h>

// neopixel
Adafruit_NeoPixel strip(8, 2, NEO_RGB + NEO_KHZ800);

// oled
#define i2cSpeed 1000000 // see
          // https://forum.pjrc.com/threads/68357-Maximum-Speed-for-using-I2C-with-SSD1306-Display
Adafruit_SSD1306 display(128, 64, &Wire, -1, i2cSpeed);
StevesAwesomeOledController oled(&display);

// synth mode
AudioSynthWaveformModulated *oscillators[4] = {&waveform1, &waveform2,
                                               &waveform3, &waveform4};
AudioEffectEnvelope *envelopes[4] = {&envelope1, &envelope2, &envelope3,
                                     &envelope4};
SynthMode *synthMode =
    new SynthMode(oscillators[0], envelopes[0], 4, &strip, &oled);

// string mode
AudioSynthKarplusStrong *strings[4] = {&string1, &string2, &string3, &string4};
StringMode *stringMode = new StringMode(strings[0], 4, &strip, &oled);

// drum mode
AudioSynthSimpleDrum *drums[4] = {&drum1, &drum2, &drum3, &drum4};
DrumMode *drumMode = new DrumMode(drums[0], 4, &strip, &oled);

// sequencer mode
AudioPlayMemory *playMems[8] = {&playMem1, &playMem2, &playMem3, &playMem4,
                                &playMem5, &playMem6, &playMem7, &playMem8};
SequencerMode *sequencerMode = new SequencerMode(playMems[0], 8, &strip, &oled);

// instrument modes
InstrumentMode *instrumentModes[] = {synthMode, stringMode, drumMode,
                                     sequencerMode};
int totalInstrumentModes = 4;
int currentInstrumentModeNum = 0;
InstrumentMode *currentInstrumentMode = synthMode;

StevesAwesomeRotaryEncoder rotaryEncoder(31, 32);

StevesAwesomeButton cButton(22, 0, INPUT_PULLUP);
StevesAwesomeButton csButton(17, 1, INPUT_PULLUP);
StevesAwesomeButton dButton(16, 2, INPUT_PULLUP);
StevesAwesomeButton dsButton(15, 3, INPUT_PULLUP);
StevesAwesomeButton eButton(14, 4, INPUT_PULLUP);
StevesAwesomeButton fButton(13, 5, INPUT_PULLUP);
StevesAwesomeButton fsButton(37, 6, INPUT_PULLUP);
StevesAwesomeButton gButton(38, 7, INPUT_PULLUP);
StevesAwesomeButton gsButton(35, 8, INPUT_PULLUP);
StevesAwesomeButton aButton(36, 9, INPUT_PULLUP);
StevesAwesomeButton asButton(33, 10, INPUT_PULLUP);
StevesAwesomeButton bButton(34, 11, INPUT_PULLUP);
StevesAwesomeButton c2Button(12, 12, INPUT_PULLUP);

StevesAwesomeButton *keyboardButtons[13] = {
    &cButton, &csButton, &dButton, &dsButton, &eButton, &fButton, &fsButton,
    &gButton, &gsButton, &aButton, &asButton, &bButton, &c2Button};

StevesAwesomeButton option1Button(28, 0, INPUT_PULLUP);
StevesAwesomeButton option2Button(29, 0, INPUT_PULLUP);
StevesAwesomeButton encoderButton(30, 0, INPUT_PULLUP);

int volumePotPin = A10;
int volumePotVal = 0;
float volumeVal = 0.0f;

int potPins[6] = {A11, A12, A13, A17, A16, A15};
int potVals[6] = {0, 0, 0, 0, 0, 0};
int *pots = potVals;

StevesAwesomePotentiometer pot1(A11, 0);
StevesAwesomePotentiometer pot2(A12, 1);
StevesAwesomePotentiometer pot3(A13, 2);
StevesAwesomePotentiometer pot4(A17, 3);

StevesAwesomePotentiometer *potObjects[4] = {&pot1, &pot2, &pot3, &pot4};

// peak meter
float peak = 0.0f;

void setup() {
  // serial
  Serial.begin(9600);

  // keyboard buttons
  for (int i = 0; i < 13; i++) {
    keyboardButtons[i]->pressHandler(notePress);
    keyboardButtons[i]->holdHandler(noteHold);
    keyboardButtons[i]->releaseHandler(noteRelease);
  }

  // other buttons
  option1Button.pressHandler(option1ButtonPress);
  option2Button.pressHandler(option2ButtonPress);
  encoderButton.pressHandler(encoderButtonPress);
  encoderButton.releaseHandler(encoderButtonRelease);

  // audio memory
  AudioMemory(1000);

  // sgtl5000
  sgtl5000_1.enable();
  sgtl5000_1.volume(0.8);
  sgtl5000_1.muteHeadphone();
  sgtl5000_1.unmuteLineout();
  sgtl5000_1.lineOutLevel(13);

  // lfo
  lfo1.begin(WAVEFORM_SINE);

  // neopixel
  strip.begin();
  strip.show();
  strip.setBrightness(20);

  // encoder
  rotaryEncoder.rightClickHandler(encoderRightClick);
  rotaryEncoder.leftClickHandler(encoderLeftClick);

  // test new pot class
  for (int i = 0; i < 4; i++) {
    potObjects[i]->turnHandler(potTurn);
  }

  currentInstrumentMode->open();
}

void loop() {
  checkVolume();
  checkButtons();
  updatePots();
  setLFO();
  setPan();
  rotaryEncoder.process();
  currentInstrumentMode->update();
}

void option1ButtonPress(int num) {
  currentInstrumentMode->option1ButtonPress();
}

void option2ButtonPress(int num) {
  currentInstrumentMode->option2ButtonPress();
}

void encoderButtonPress(int num) { Serial.println("encoder press"); }

void encoderButtonRelease(int num) { Serial.println("encoder release"); }

void notePress(int num) { currentInstrumentMode->onNoteButtonPress(num); }

void noteHold(int num) { currentInstrumentMode->onNoteButtonHold(num); }

void noteRelease(int num) { currentInstrumentMode->onNoteButtonRelease(num); }

void potTurn(int num, int val) {
  currentInstrumentMode->updatePotVal(num, val);
}

void nextInstrumentMode() {
  currentInstrumentModeNum++;
  if (currentInstrumentModeNum >= totalInstrumentModes)
    currentInstrumentModeNum = 0;
  currentInstrumentMode = instrumentModes[currentInstrumentModeNum];
}

void encoderRightClick() {
  lockPots();
  currentInstrumentMode->close();
  nextInstrumentMode();
  currentInstrumentMode->open();
}

void previousInstrumentMode() {
  currentInstrumentModeNum--;
  if (currentInstrumentModeNum < 0)
    currentInstrumentModeNum = totalInstrumentModes - 1;
  currentInstrumentMode = instrumentModes[currentInstrumentModeNum];
}

void encoderLeftClick() {
  lockPots();
  currentInstrumentMode->close();
  previousInstrumentMode();
  currentInstrumentMode->open();
}

void lockPots() {
  for (int i = 0; i < 4; i++) {
    potObjects[i]->lock();
  }
}

void checkVolume() {
  volumePotVal = analogRead(volumePotPin);
  volumeVal = map(volumePotVal, 0, 1023, 0, 100) / 100.0;
}

void updatePots() {
  for (int i = 0; i < 4; i++) {
    // potVals[i] = analogRead(potPins[i]);  // this is the old way
    potObjects[i]->update();
  }
}

void setLFO() {
  int val = analogRead(potPins[5]);
  if (val > 5) {
    float frequency = map(val, 5, 1023, 0, 2000) / 100.0;
    lfo1.frequency(frequency);
    lfo1.amplitude(1);
    multiplyMixer.gain(0, 0);
    multiplyMixer.gain(1, 1);
  } else {
    // bypass it
    multiplyMixer.gain(0, 1);
    multiplyMixer.gain(1, 0);
  }
}

void setPan() {
  float panVal = map(analogRead(potPins[4]), 0, 1023, -100, 100) / 100.0;
  if (panVal < 0.0) {
    amp1.gain(volumeVal);
    amp2.gain((1 + panVal) * volumeVal);
  } else {
    amp1.gain((1 - panVal) * volumeVal);
    amp2.gain(volumeVal);
  }
}

void checkButtons() {
  option1Button.process();
  option2Button.process();
  encoderButton.process();

  for (int i = 0; i < 13; i++) {
    keyboardButtons[i]->process();
  }
}

void checkPeak() {
  if (peak1.available()) peak = peak1.read();
}