// Audio data converted from WAV file by wav2sketch

extern const unsigned int AudioSampleKick808[1409];
