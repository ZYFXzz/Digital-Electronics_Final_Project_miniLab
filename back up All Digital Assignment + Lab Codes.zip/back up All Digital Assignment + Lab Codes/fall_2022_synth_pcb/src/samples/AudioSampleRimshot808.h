// Audio data converted from WAV file by wav2sketch

extern const unsigned int AudioSampleRimshot808[1409];
