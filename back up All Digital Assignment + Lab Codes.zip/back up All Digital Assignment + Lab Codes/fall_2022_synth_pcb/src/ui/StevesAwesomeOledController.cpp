#include "StevesAwesomeOledController.h"

StevesAwesomeOledController::StevesAwesomeOledController(Adafruit_SSD1306 *_oled)
{
    oled = _oled;

    oled->begin(SSD1306_SWITCHCAPVCC, 0x3C);
    oled->clearDisplay();
    oled->display();

    // draw circles
    for (int16_t i = max(oled->width(), oled->height()) / 2; i > 0; i -= 3)
    {
        oled->fillCircle(oled->width() / 2, oled->height() / 2, i, SSD1306_INVERSE); // The INVERSE color is used so circles alternate white/black
        oled->display();
    }

  // for later
  // if (notesPlaying < totalOscs) {
  //   display.clearDisplay();
  //   displayInverted = !displayInverted;
  //   display.invertDisplay(displayInverted);
  //   drawRandomThing();    
}

void StevesAwesomeOledController::drawRandomShape()
{
    int shape = 0;
    if (shape == 0)
    {
        oled->drawCircle(random(oled->width()) - 1, random(oled->height()) - 1, random(oled->height()) - 1, SSD1306_WHITE);
        oled->display();
    }
    else if (shape == 1)
    {
        int y = random(oled->height());
        oled->drawLine(0, y, oled->width(), y, SSD1306_WHITE);
        oled->display();
    }
    else if (shape == 2)
    {
        oled->drawPixel(random(oled->width()), random(oled->height()), SSD1306_WHITE);
        oled->display();
    }
    else if (shape == 3)
    {
        displayInverted = !displayInverted;
        oled->clearDisplay();
        oled->invertDisplay(displayInverted);
        oled->display();
    }
}

void StevesAwesomeOledController::clear()
{
    oled->clearDisplay();
    oled->display();
}