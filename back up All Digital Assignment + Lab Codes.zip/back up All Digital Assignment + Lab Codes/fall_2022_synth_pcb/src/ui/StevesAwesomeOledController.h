#ifndef StevesAwesomeOledController_h
#define StevesAwesomeOledController_h

#include <Adafruit_SSD1306.h>

class StevesAwesomeOledController
{
public:
    StevesAwesomeOledController(Adafruit_SSD1306 *_oled);
    void drawRandomShape();
    void clear();
private:
    Adafruit_SSD1306 *oled;
    bool displayInverted = false;
};

#endif
