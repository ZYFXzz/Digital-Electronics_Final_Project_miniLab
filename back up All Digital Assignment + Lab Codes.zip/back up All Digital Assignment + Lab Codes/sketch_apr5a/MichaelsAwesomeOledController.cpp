#ifndef MichaelsAwesomeOledController_h
#define MichaelsAwesomeOledController_h

#include <Adafurit_SSD1306.h>

class MichaelsAwesomeOledController
{
  public:
  MichaelsAwesomeOledController(Adafruit_SSD1306 * oled);
  void displayButtonPressed(String _buttonName=NULL, int _midiNumb);
  void displayCcValueSent(int _ccValue, String _ccName) {
  void clear();
  private:
  Adafruit_SSD1306 *oled;  // why this line?
}