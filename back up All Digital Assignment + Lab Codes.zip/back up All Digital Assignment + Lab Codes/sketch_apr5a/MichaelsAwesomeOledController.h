#include "WString.h"
#include "MichaelsAwesomeOledController.h"

MichaelsAswesomeOledController::MichaelsAwesomeOledController(Adafruit_SSD1306 *_oled) {
  oled = _oled;

  oled->begin(SSD1306_SWITCHCAPVCC, 0x3c);
  oled->clearDisplay();
  oled->display();

  //print "Hello, world"
  oled->clearDisplay();

  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);
  display.setCursor(0, 28);
  display.println(F("Hello, world"));

  oled->display();
}

void MichaelsAwesomeOledController::displayCcValueSent(int _ccValue, String _ccName) {
  oled->clearDisplay();

  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);
  display.setCursor(0, 28);
  display.print(F(_ccName));//print _ccName
  display.println(_ccValue);

  oled->display();
}

void MichaelsAwesomeOledController::displayButtonPressed(String _buttonName=NULL, int _midiNumb){
  display.clearDisplay();

  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);
  display.setCursor(0, 28);
  display.print(F("Midi Note "));
  display.pring(_midiNumb);
  display.print(F(_buttonName));//print _ccName
  display.println(F(" is pressed"));

  display.display();
  delay(2000);
}



void MichaelsAwesomeOledController::clear() {
  oled->clearDisplay();
  oled->display();
}
